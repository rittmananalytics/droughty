import os
import pandas as pd
from google.oauth2 import service_account
import yaml  # Import PyYAML to read the YAML file
from pydantic_ai import Agent
from pydantic import BaseModel, ValidationError
from typing import Dict, Any

from droughty.droughty_core.config import ProjectVariables, droughty_assumptions

# Load project variables
credentials = ProjectVariables.service_account
project = ProjectVariables.project
openai_api_key = ProjectVariables.openai_secret

# Define a Pydantic model for expectation validation
class ColumnExpectation(BaseModel):
    expectation: str
    severity: str = "warning"  # Severity can be "warning" or "error"

# Function to query BigQuery using pandas.read_gbq
def query_bigquery(query, project, credentials):
    """Executes a SQL query on BigQuery using pandas.read_gbq and returns the result."""
    df = pd.read_gbq(query, dialect='standard', project_id=project, credentials=credentials)
    return df

# Function to validate a DataFrame column using Pydantic AI
def validate_column_with_ai(expectation: str, column_data: pd.Series, agent: Agent) -> Dict[str, Any]:
    """Validate column data using Pydantic AI agent."""
    # Convert the column data to a string format for input
    column_summary = column_data.to_string(index=False, header=False)

    # Create the input text
    input_text = (
        f"Expectation: {expectation}\n"
        f"Column Data:\n{column_summary}\n"
        f"Please validate the data based on the expectation and identify any issues."
    )

    # Use the agent to process the input
    result = agent.run_sync(input_text)
    return {
        "validated": True,
        "output": result.data
    }

# Load the expectations from the YAML file
yaml_data = droughty_assumptions

# Define the Pydantic AI agent
agent = Agent(
    model="gemini-1.5-flash",
    system_prompt="You are a data QA agent. Validate column data against expectations and provide concise feedback."
)

# Function to process a single column
def process_column(column_name: str, column_data: pd.Series, column_expectations: list, agent: Agent):
    """Process expectations for a single column."""
    results = []

    for expectation_entry in column_expectations:
        try:
            # Parse the expectation entry
            expectation = ColumnExpectation(**expectation_entry)

            # Validate the column data
            result = validate_column_with_ai(expectation.expectation, column_data, agent)

            # Append results with additional metadata
            results.append({
                "column_name": column_name,
                "expectation": expectation.expectation,
                "severity": expectation.severity,
                "result": result
            })

        except ValidationError as e:
            results.append({
                "column_name": column_name,
                "error": f"Invalid expectation definition: {e}"
            })

    return results

# Iterate over the expectations and apply them to the respective columns
def process_yaml_expectations(yaml_data, agent, project, credentials):
    """Process the expectations from the YAML file and apply them to the dataframe."""
    qa_results = []

    for dataset_name, dataset_data in yaml_data['datasets'].items():
        for table_name, table_data in dataset_data['tables'].items():
            columns_to_query = list(table_data['columns'].keys())

            # Generate the SQL query dynamically
            query = f"SELECT {', '.join(columns_to_query)} FROM `{project}.{dataset_name}.{table_name}`"
            print(f"Running query for table '{table_name}' in dataset '{dataset_name}':\n{query}")

            # Query BigQuery and load the DataFrame
            dataframe = query_bigquery(query, project, credentials)

            for column_name, column_expectations in table_data['columns'].items():
                if column_name in dataframe.columns:
                    print(f"Processing column '{column_name}'...")

                    # Process expectations for the column
                    results = process_column(column_name, dataframe[column_name], column_expectations, agent)
                    qa_results.extend(results)
                else:
                    qa_results.append({
                        "column_name": column_name,
                        "error": "Column not found in the dataframe."
                    })

    return qa_results

# Main function to orchestrate the process
def qa_agent():
    results = process_yaml_expectations(yaml_data, agent, project, credentials)

    # Generate a QA summary report
    for result in results:
        if "error" in result:
            print(f"[ERROR] {result['column_name']}: {result['error']}")
        else:
            print(f"[{result['severity'].upper()}] {result['column_name']}: {result['expectation']}\n{result['result']['output']}\n")

# Call the main function
qa_agent()
