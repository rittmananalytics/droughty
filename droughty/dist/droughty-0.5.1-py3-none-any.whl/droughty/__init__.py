"""Top-level package for droughty."""

__author__ = """Lewis Baker"""
__email__ = 'lewischarlebaker@gmail.com'
__version__ = '0.1.0'
