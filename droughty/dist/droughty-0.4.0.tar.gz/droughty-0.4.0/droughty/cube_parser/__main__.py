if __name__ == "__main__":
    from cube_parser import cli

    cli()
