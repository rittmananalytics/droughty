from google.oauth2 import service_account
import pandas_gbq
from contextlib import redirect_stdout
import snowflake.connector
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL
import pandas as pd
import pandas
import os
import json
import sys
import yaml
import git

import droughty.cube_parser.cube as cube

from droughty.droughty_cube.cube_base_dict import get_cube_base_dict
from droughty.droughty_cube.cube_explore_dict import get_cube_explore_dict
from droughty.droughty_core.config import (
    ProjectVariables,
    ExploresVariables,
    IdentifyConfigVariables
)

def get_all_values(nested_dictionary,explore_dictionary):
    
    for key,value in nested_dictionary.items():
    
        for explore_key, explore_value in explore_dictionary.items():

            if explore_key in key:

                explore = {


                    "cube": key,
                    "sql": "select * from"+" "+ProjectVariables.schema+"."+key,
                    "joins ": "{"

                }


                yield(cube.dump(explore))
        

                for key1, value1 in explore_value.items():
                    

                    join = {


                        "joins": 
                        [
                        
                        {
                        "relationship": key1[3],
                        "sql": "${CUBE."+str(key1[0])+"}"+" = "+"${"+str(key1[1])+"."+str(key1[2])+"}",
                        "name": key1[1]

                        }
                            
                        ]

                    }
                    
                    

                    yield(cube.dump(join))
                    
                    join_end = "}, "                 

                yield(join_end)
                
                        
                dimension_start = "dimensions: {"

                yield(dimension_start)


                for key1, value1 in value.items():
                    
                    if "pk" not in key1[0]: #and "number" not in key1 [1]:  
                    
                        dimension = {


                            "dimension": {
                            "sql": key1[0],
                            "type": key1[1],
                            "name": key1[0],
                            "description": key1[2]


                            }

                        }
                    
                        yield(cube.dump(dimension))
                        
                    elif "pk" in key1[0]:

                        dimension = {


                            "dimension": {
                                "primaryKey": "true",
                                "type": key1[1],
                                "sql": key1[0],
                                "name": key1[0],
                                "description": key1[2]

                            }
                        }

                        yield(cube.dump(dimension))

                closing_syntax = "} ,"

                yield (closing_syntax)

                measure_start = "measures: {"

                yield(measure_start)

                for key1, value1 in value.items():
                    
                    if "pk" in key1[0]:

                        measure = {


                            "measure": {
                            "sql": key1[0],
                            "type": "count",
                            "name": "count_of_"+key1[0]

                            }

                        }

                        yield(cube.dump(measure))
                        

                    if key1[1] == 'number':

                        measure = {


                            "measure": {
                            "sql": key1[0],
                            "type": "sum",
                            "name": "sum_of_"+key1[0]

                            }

                        }

                        yield(cube.dump(measure))
                
                
                for key,value in nested_dictionary.items():

                    closing_syntax = "}});"

                yield (closing_syntax)

def get_git_root(path):

        git_repo = git.Repo(path, search_parent_directories=True)
        git_root = git_repo.git.rev_parse("--show-toplevel")
        return (git_root)

git_def_path = get_git_root(os.getcwd())


def explore_output():
    
    if ExploresVariables.cube_path == None:
 
        git_path = IdentifyConfigVariables.git_path

        rel_path = "schema"

        path = os.path.join(git_path, rel_path)

    elif ExploresVariables.cube_path != None:

        path = os.path.join(IdentifyConfigVariables.git_path,ExploresVariables.cube_path)

    if not os.path.exists(path):
        os.makedirs(path)

    if ExploresVariables.cube_integration_filename != None:

        filename = ExploresVariables.cube_integration_filename
        
    else:
        
        filename = 'cube_integration'

    suffix = '.js'

    extension = filename+suffix

    with open(os.path.join(path,extension), 'w') as file:

        with redirect_stdout(file):

                for value in get_all_values(get_cube_base_dict(),get_cube_explore_dict()):

                    print(value)