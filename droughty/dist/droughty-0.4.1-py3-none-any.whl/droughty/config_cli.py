from dataclasses import dataclass
import argparse

import os
import yaml

@dataclass
class Common:

    profile_dir: str
    args_command: str

def some_function_1(profile_dir):
    """Some example funcion"""
    msg = profile_dir
    print(msg + "function test")

def profile_func():

    # creating core parser

    profile_parser = argparse.ArgumentParser(description='Say hi.')
    profile_parser.add_argument('--profile-dir', type=str, help='the directory of the profile')

    # creating sub-parser 

    subparser = profile_parser.add_subparsers(dest='command')

    # lookml sub-parser 

    lookml = subparser.add_parser('lookml')
    lookml.add_argument('--profile-dir', type=str, required=False)

    action_subparser = lookml.add_subparsers(title="base")
    base = action_subparser.add_parser('base')
    base.add_argument('--profile-dir', type=str, required=False)

    args = profile_parser.parse_args()
    sub_args = base.parse_args()

    #some_function_1(args.profile_dir)

    if args.command == 'lookml':
        print(args," ",sub_args)
    else:
        pass
       
    Common.args_command = (args.command)

    Common.profile_dir = (args.profile_dir)

 
profile_func()

# parent_parser = argparse.ArgumentParser(add_help=False)
# parent_parser.add_argument('--user', '-u',
#                     default=getpass.getuser(),
#                     help='username')
# parent_parser.add_argument('--debug', default=False, required=False,
#                         action='store_true', dest="debug", help='debug flag')
# main_parser = argparse.ArgumentParser()
# service_subparsers = main_parser.add_subparsers(title="service",
#                     dest="service_command")
# service_parser = service_subparsers.add_parser("first", help="first",
#                     parents=[parent_parser])
# action_subparser = service_parser.add_subparsers(title="action",
#                     dest="action_command")
# action_parser = action_subparser.add_parser("second", help="second",
#                     parents=[parent_parser])
# 
# args = main_parser.parse_args()